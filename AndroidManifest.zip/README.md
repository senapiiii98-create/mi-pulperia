# 🛒 Pulpería La Negrita — Android

Proyecto Android base con lector de códigos de barras y preparado para compilar la APK automáticamente en GitHub Actions.

## Subirlo a GitHub

Puedes subir **el contenido de esta carpeta** a un repositorio nuevo (no es necesario subir el ZIP dentro del repositorio).

1. Crea un repositorio nuevo en GitHub.
2. Sube `app/`, `build.gradle.kts`, `settings.gradle.kts`, `.github/` y los demás archivos.
3. Entra en **Actions**.
4. Selecciona **Compilar APK - Pulpería La Negrita**.
5. Pulsa **Run workflow**.
6. Espera a que termine con ✓.
7. Abre la ejecución y baja hasta **Artifacts**.
8. Descarga **PulperiaLaNegrita-debug**.
9. Dentro estará `app-debug.apk` para instalarlo en Android.

También se ejecutará automáticamente cada vez que hagas push a `main` o `master`.

## Qué corrige esta versión

- Incluye el workflow de GitHub Actions que faltaba en el ZIP original.
- Configura Java 17.
- Configura Gradle 8.9.
- Instala explícitamente Android SDK 35 y Build Tools 35.0.0.
- Compila con `clean assembleDebug` para evitar residuos de compilaciones anteriores.

## Requisitos del proyecto

- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Compile SDK 35
- Java 17

## Estado de la app

Esta es la base inicial: nombre Pulpería La Negrita, pantalla Android y lector de códigos de barras. El catálogo, precios, carrito, inventario, ventas, ganancias y reportes se pueden integrar en la siguiente versión.
