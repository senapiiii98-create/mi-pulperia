# Pulpería La Negrita — Android

Proyecto Android base con lector de códigos de barras mediante cámara (ZXing).

## Abrir y compilar
1. Abre esta carpeta en Android Studio.
2. Espera a que Gradle sincronice las dependencias.
3. Ejecuta en un teléfono Android o usa Build > Generate App Bundles or APKs > Generate APKs.
4. La app solicitará permiso de cámara al escanear.

## Próxima integración
La base está preparada para conectar el catálogo, precios, carrito, inventario, ventas y reportes.
