package com.pulperialanegrita.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var code: EditText
    private val requestCamera = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) scanBarcode() else status.text = "Permiso de cámara necesario para escanear."
    }
    private val scanner = registerForActivityResult(ScanContract()) { result ->
        if (result.contents != null) {
            code.setText(result.contents)
            status.text = "Código leído: ${result.contents}"
        } else status.text = "Escaneo cancelado."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main)

        status = findViewById(R.id.status)
        code = findViewById(R.id.code)

        findViewById<Button>(R.id.scan).setOnClickListener {
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                scanBarcode()
            else requestCamera.launch(Manifest.permission.CAMERA)
        }

        findViewById<Button>(R.id.demo).setOnClickListener {
            status.text = "Base de Pulpería La Negrita lista. Aquí conectaremos productos, ventas e inventario."
        }
    }

    private fun scanBarcode() {
        val options = ScanOptions().apply {
            setDesiredBarcodeFormats(ScanOptions.ALL_CODE_TYPES)
            setPrompt("Apunta al código de barras")
            setBeepEnabled(true)
            setOrientationLocked(true)
        }
        scanner.launch(options)
    }
}
