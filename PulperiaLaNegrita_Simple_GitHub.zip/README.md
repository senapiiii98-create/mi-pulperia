# Pulpería La Negrita - versión simple

Proyecto Android minimalista para evitar conflictos de dependencias.

NO usa Material Components, AndroidX, AppCompat, ViewPager2, Kotlin ni librerías externas.

Usa Java y controles clásicos de Android.

Incluye productos, códigos, precios, inventario, carrito, ventas, historial y almacenamiento local.

Esta primera versión no incluye cámara: se puede escribir el código o usar un lector Bluetooth/USB que funcione como teclado. Primero se busca una compilación estable; el escaneo por cámara puede añadirse después.

GitHub Actions genera app/build/outputs/apk/debug/app-debug.apk y lo publica como Artifact: PulperiaLaNegrita-debug.
